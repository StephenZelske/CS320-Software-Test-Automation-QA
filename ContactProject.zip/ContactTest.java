/*
 * Stephen Zelske
 * CS-320
 * 10/11/2026
 */


package Tests;


import static org.junit.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import Contact.Contact;

public class ContactTest {
	private static Contact contact;
	
	@BeforeEach
	void resetContact() {
		contact = new Contact();
	}
	
	@Test
	void testContactID() {
		Contact contactID = new Contact("7654321", "Tony", "Hummer", "address", "312630224");
		Assertions.assertTrue(contactID.getContactID().equals("7654321"));
		Assertions.assertTrue(contactID.getAddress().equals("address"));
		Assertions.assertTrue(contactID.getFirstName().equals("Tony"));
		
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("7654321", "Tony", "Hummer", "address", "312630224");
		});
	}
	
	@Test
	void testSetPhoneNumber() {
		Assertions.assertThrows(IllgalArgumentException.class, () -> {
			contact.setPhoneNumber("3122246304457734407770");
		});
	}
	
	@Test
	void testSetAddress() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setAddress("24578lkolkolkgffrthhkhjjjkh8731314fgdjdjfd");
		});
	}
	
	@Test
	void testSetFirstName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setFirstName("CharlieLouisianaAustinTexasAtlantaGeorgiaChicagoIllinoisChampaignUrbana");
		});
	}
	
	@Test
	void testSetLastName() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.setLastName("SmithJohnsonRobinsonLewisChubbsSandlerCarellChappelleBurrWilliams");
		});
	}
		
	
}
