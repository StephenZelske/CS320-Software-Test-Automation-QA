/*
 * Stephen Zelske
 * CS-320
 * 10/11/2026
 */


package Tests;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Contact.ContactService;
import Contact.Contact;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
	private static ContactService contactService;
	
	@BeforeEach
	void setUpContactService() {
		contactService = new ContactService();
		contactService.addContact(new Contact("1234567", "Kobe", "Bryant", "248 Lakers Way", "213504332"));
	}
	
	@Test
	void updateFirstName() {
		Contact c = new Contact("1234567", "Kobe", "Bryant", "248 Lakers Way", "213504332");
		ContactService cs = new ContactService();
		cs.addContact(new Contact("1234567", "Kobe", "ONeal", "248 Lakers Way", "213504332"));
		cs.updateLastName("1234567", "Bryant");
		Assert.assertEquals(c.getLastName(), cs.getContact("1234567").getLastName());
	}
	
	@Test
	void addContactFailsTest() {
		contactService.addContact(new Contact("1234567", "Shaq", "Bryant", "248 Lakers Way", "213504332"));
		Assertions.assertFalse(contactService.getContact("1234567").getFirstName().equals("Shaq"));
	};
	
	@Test
	void deleteContactSucceedsTest() {
		Assertions.assertTrue(contactService.deleteContact("1234567"));
	}
	
	@Test
	void updateAddress() {
		contactService.updateAddress("1234567", "new Address");
		Assertions.assertEquals(contactService.getContact("1234567").getAddress(), "new Address");
	}
	
}
		
		
		
	
	
	
	
